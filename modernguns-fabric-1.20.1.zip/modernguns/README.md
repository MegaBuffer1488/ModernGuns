Modern Guns (Fabric 1.20.1). Сборка: gradle build -> build/libs/modernguns-1.0.0.jar
