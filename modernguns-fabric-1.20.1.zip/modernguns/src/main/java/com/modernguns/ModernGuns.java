package com.modernguns;

import net.fabricmc.api.ModInitializer;

public class ModernGuns implements ModInitializer {
    public static final String MOD_ID = "modernguns";

    @Override
    public void onInitialize() {
        ModItems.init();
    }
}
