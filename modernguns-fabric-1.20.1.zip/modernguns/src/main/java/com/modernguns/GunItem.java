package com.modernguns;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;

public class GunItem extends Item {
    private final GunKind kind;
    private final float damage;
    private final int delay;
    private final boolean auto;
    private final float spread;
    private final int pellets;

    public GunItem(Settings settings, GunKind kind, float damage, int delay, boolean auto, float spread, int pellets) {
        super(settings);
        this.kind = kind;
        this.damage = damage;
        this.delay = delay;
        this.auto = auto;
        this.spread = spread;
        this.pellets = pellets;
    }

    private Item ammo() {
        return switch (kind) {
            case PISTOL, SMG -> ModItems.AMMO_PISTOL;
            case RIFLE, LMG -> ModItems.AMMO_RIFLE;
            case SHOTGUN -> ModItems.AMMO_SHOTGUN;
            case SNIPER -> ModItems.AMMO_SNIPER;
        };
    }

    private boolean hasAmmo(PlayerEntity p) {
        if (p.isCreative()) return true;
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ammo())) return true;
        }
        return false;
    }

    private void takeAmmo(PlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(ammo())) {
                s.decrement(1);
                return;
            }
        }
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        if (!hasAmmo(player)) {
            if (!world.isClient) {
                player.sendMessage(Text.literal("Нет патронов!").formatted(Formatting.RED), true);
                world.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.BLOCK_DISPENSER_FAIL, SoundCategory.PLAYERS, 1.0f, 1.5f);
            }
            return TypedActionResult.fail(stack);
        }
        if (world instanceof ServerWorld sw) {
            fire(sw, player);
        }
        if (auto) {
            player.setCurrentHand(hand);
            return TypedActionResult.consume(stack);
        }
        return TypedActionResult.success(stack);
    }

    @Override
    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
        if (!(world instanceof ServerWorld sw) || !(user instanceof PlayerEntity player)) return;
        if (!auto || player.getItemCooldownManager().isCoolingDown(this)) return;
        if (!hasAmmo(player)) {
            player.stopUsingItem();
            player.sendMessage(Text.literal("Нет патронов!").formatted(Formatting.RED), true);
            return;
        }
        fire(sw, player);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.NONE;
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 72000;
    }

    private void fire(ServerWorld world, PlayerEntity player) {
        if (!player.isCreative()) takeAmmo(player);
        player.getItemCooldownManager().set(this, delay);

        float sp = spread;
        if (player.isSneaking()) sp *= 0.5f;
        if (!player.isOnGround()) sp *= 1.5f;

        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0f);
        Random rnd = world.getRandom();
        for (int i = 0; i < pellets; i++) {
            Vec3d dir = look.add(rnd.nextGaussian() * sp, rnd.nextGaussian() * sp, rnd.nextGaussian() * sp).normalize();
            shoot(world, player, eye, dir);
        }

        SoundEvent snd = SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST;
        float vol = 1.0f, pitch = 1.2f;
        switch (kind) {
            case PISTOL -> pitch = 1.6f;
            case SMG -> { pitch = 1.9f; vol = 0.8f; }
            case RIFLE -> pitch = 1.2f;
            case LMG -> pitch = 0.9f;
            case SHOTGUN -> { snd = SoundEvents.ENTITY_GENERIC_EXPLODE; vol = 0.5f; pitch = 1.6f; }
            case SNIPER -> { snd = SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST; vol = 2.0f; pitch = 0.8f; }
        }
        world.playSound(null, player.getX(), player.getY(), player.getZ(), snd, SoundCategory.PLAYERS, vol, pitch);
    }

    private void shoot(ServerWorld world, PlayerEntity player, Vec3d eye, Vec3d dir) {
        double range = kind.range;
        Vec3d end = eye.add(dir.multiply(range));
        boolean hitBlock = false;

        HitResult block = world.raycast(new RaycastContext(eye, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (block.getType() != HitResult.Type.MISS) {
            end = block.getPos();
            hitBlock = true;
        }

        Box box = player.getBoundingBox().stretch(dir.multiply(range)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(player, eye, end, box,
                e -> !e.isSpectator() && e.isAlive() && e.canHit(), range * range);

        if (hit != null) {
            Entity target = hit.getEntity();
            end = hit.getPos();
            hitBlock = false;
            float dmg = damage;
            if (end.y > target.getEyeY() - 0.2) dmg *= 1.5f; // хедшот
            target.timeUntilRegen = 0;
            target.damage(world.getDamageSources().playerAttack(player), dmg);
        }

        double dist = eye.distanceTo(end);
        for (double d = 2.0; d < dist; d += 2.0) {
            Vec3d p = eye.add(dir.multiply(d));
            world.spawnParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        if (hitBlock) {
            world.spawnParticles(ParticleTypes.SMOKE, end.x, end.y, end.z, 3, 0.05, 0.05, 0.05, 0.01);
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        String dmg = pellets > 1 ? damage + " x" + pellets : String.valueOf(damage);
        tooltip.add(Text.literal("Урон: " + dmg).formatted(Formatting.GRAY));
        tooltip.add(Text.literal(auto ? "Режим: автоматический" : "Режим: одиночный").formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.modernguns.ammo", Text.translatable(ammo().getTranslationKey()))
                .formatted(Formatting.DARK_GRAY));
    }
}
