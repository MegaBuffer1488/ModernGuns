package com.modernguns;

public enum GunKind {
    PISTOL(50), SMG(60), RIFLE(90), LMG(90), SHOTGUN(30), SNIPER(200);

    public final double range;

    GunKind(double range) {
        this.range = range;
    }
}
