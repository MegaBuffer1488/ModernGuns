package com.modernguns;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class ModItems {
    public static final List<Item> ALL = new ArrayList<>();

    // --- патроны ---
    public static final Item AMMO_PISTOL = register("ammo_pistol", new Item(new FabricItemSettings()));
    public static final Item AMMO_RIFLE = register("ammo_rifle", new Item(new FabricItemSettings()));
    public static final Item AMMO_SHOTGUN = register("ammo_shotgun", new Item(new FabricItemSettings()));
    public static final Item AMMO_SNIPER = register("ammo_sniper", new Item(new FabricItemSettings()));

    // --- оружие ---
    public static final Item GLOCK17 = gun("glock17", GunKind.PISTOL, 5.0f, 4, false, 0.02f, 1);
    public static final Item USP = gun("usp", GunKind.PISTOL, 6.0f, 5, false, 0.02f, 1);
    public static final Item MAKAROV = gun("makarov", GunKind.PISTOL, 4.5f, 4, false, 0.025f, 1);
    public static final Item M1911 = gun("m1911", GunKind.PISTOL, 6.5f, 6, false, 0.02f, 1);
    public static final Item DEAGLE = gun("deagle", GunKind.PISTOL, 10.0f, 14, false, 0.015f, 1);
    public static final Item PYTHON = gun("python", GunKind.PISTOL, 11.0f, 16, false, 0.01f, 1);
    public static final Item MP5 = gun("mp5", GunKind.SMG, 3.5f, 2, true, 0.03f, 1);
    public static final Item UZI = gun("uzi", GunKind.SMG, 3.5f, 2, true, 0.035f, 1);
    public static final Item P90 = gun("p90", GunKind.SMG, 3.0f, 1, true, 0.03f, 1);
    public static final Item VECTOR = gun("vector", GunKind.SMG, 3.0f, 1, true, 0.03f, 1);
    public static final Item MAC10 = gun("mac10", GunKind.SMG, 3.0f, 1, true, 0.055f, 1);
    public static final Item UMP45 = gun("ump45", GunKind.SMG, 4.0f, 2, true, 0.03f, 1);
    public static final Item AK47 = gun("ak47", GunKind.RIFLE, 6.0f, 3, true, 0.03f, 1);
    public static final Item AKM = gun("akm", GunKind.RIFLE, 6.5f, 3, true, 0.03f, 1);
    public static final Item AK74 = gun("ak74", GunKind.RIFLE, 5.5f, 3, true, 0.025f, 1);
    public static final Item AKS74U = gun("aks74u", GunKind.RIFLE, 5.0f, 2, true, 0.04f, 1);
    public static final Item AK12 = gun("ak12", GunKind.RIFLE, 6.0f, 3, true, 0.022f, 1);
    public static final Item M4A1 = gun("m4a1", GunKind.RIFLE, 5.0f, 2, true, 0.02f, 1);
    public static final Item HK416 = gun("hk416", GunKind.RIFLE, 5.5f, 2, true, 0.018f, 1);
    public static final Item SCARH = gun("scarh", GunKind.RIFLE, 7.5f, 3, true, 0.025f, 1);
    public static final Item AUG = gun("aug", GunKind.RIFLE, 5.0f, 2, true, 0.02f, 1);
    public static final Item FAMAS = gun("famas", GunKind.RIFLE, 5.0f, 2, true, 0.022f, 1);
    public static final Item G36 = gun("g36", GunKind.RIFLE, 5.0f, 2, true, 0.02f, 1);
    public static final Item M16A4 = gun("m16a4", GunKind.RIFLE, 5.5f, 3, true, 0.02f, 1);
    public static final Item M14 = gun("m14", GunKind.RIFLE, 8.0f, 6, false, 0.012f, 1);
    public static final Item FAL = gun("fal", GunKind.RIFLE, 7.5f, 5, false, 0.015f, 1);
    public static final Item SKS = gun("sks", GunKind.RIFLE, 7.0f, 6, false, 0.015f, 1);
    public static final Item M249 = gun("m249", GunKind.LMG, 5.0f, 2, true, 0.05f, 1);
    public static final Item PKM = gun("pkm", GunKind.LMG, 6.0f, 3, true, 0.05f, 1);
    public static final Item RPK = gun("rpk", GunKind.LMG, 5.5f, 3, true, 0.04f, 1);
    public static final Item REMINGTON870 = gun("remington870", GunKind.SHOTGUN, 2.0f, 20, false, 0.07f, 8);
    public static final Item SPAS12 = gun("spas12", GunKind.SHOTGUN, 2.0f, 14, false, 0.07f, 8);
    public static final Item MOSSBERG500 = gun("mossberg500", GunKind.SHOTGUN, 2.0f, 18, false, 0.07f, 8);
    public static final Item AA12 = gun("aa12", GunKind.SHOTGUN, 1.6f, 5, true, 0.085f, 7);
    public static final Item DOUBLEBARREL = gun("doublebarrel", GunKind.SHOTGUN, 2.2f, 16, false, 0.06f, 10);
    public static final Item AWP = gun("awp", GunKind.SNIPER, 20.0f, 30, false, 0.0f, 1);
    public static final Item BARRETT = gun("barrett", GunKind.SNIPER, 18.0f, 20, false, 0.002f, 1);
    public static final Item SVD = gun("svd", GunKind.SNIPER, 12.0f, 12, false, 0.004f, 1);
    public static final Item M24 = gun("m24", GunKind.SNIPER, 16.0f, 25, false, 0.0f, 1);

    private static Item gun(String id, GunKind kind, float dmg, int delay, boolean auto, float spread, int pellets) {
        return register(id, new GunItem(new FabricItemSettings().maxCount(1), kind, dmg, delay, auto, spread, pellets));
    }

    private static Item register(String id, Item item) {
        ALL.add(item);
        return Registry.register(Registries.ITEM, new Identifier(ModernGuns.MOD_ID, id), item);
    }

    public static void init() {
        Registry.register(Registries.ITEM_GROUP, new Identifier(ModernGuns.MOD_ID, "guns"),
                FabricItemGroup.builder()
                        .icon(() -> new ItemStack(AK47))
                        .displayName(Text.translatable("itemGroup.modernguns.guns"))
                        .entries((ctx, entries) -> {
                            for (Item i : ALL) entries.add(i);
                        })
                        .build());
    }
}
